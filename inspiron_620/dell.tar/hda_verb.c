/* SPDX-License-Identifier: GPL-2.0-only */

#include <device/azalia_device.h>

const u32 cim_verb_data[] = {
};

const u32 pc_beep_verbs[0] = {};

AZALIA_ARRAY_SIZES;
